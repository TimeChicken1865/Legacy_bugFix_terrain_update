// Made with Blockbench 3.9.2
// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
// Paste this class into your mod and generate all required imports

public static class Modelslash extends EntityModel<Entity> {
	private final ModelRenderer bone;
	private final ModelRenderer bone2;
	private final ModelRenderer bone3;
	private final ModelRenderer bone4;
	private final ModelRenderer bone5;
	private final ModelRenderer bone6;
	private final ModelRenderer bone7;
	private final ModelRenderer bone8;

	public Modelslash() {
		textureWidth = 16;
		textureHeight = 16;

		bone = new ModelRenderer(this);
		bone.setRotationPoint(0.0F, 24.0F, 1.5F);
		bone.setTextureOffset(0, 0).addBox(1.0F, -1.0F, -2.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone.setTextureOffset(0, 2).addBox(-5.0F, -1.0F, -2.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone.setTextureOffset(0, 4).addBox(-2.0F, -1.0F, -3.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);

		bone2 = new ModelRenderer(this);
		bone2.setRotationPoint(0.0F, -0.5F, -1.8333F);
		bone.addChild(bone2);
		setRotationAngle(bone2, 0.0F, 0.0F, 1.5708F);
		bone2.setTextureOffset(0, 0).addBox(1.0F, -0.5F, -0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone2.setTextureOffset(0, 2).addBox(-5.0F, -0.5F, -0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone2.setTextureOffset(0, 4).addBox(-2.0F, -0.5F, -1.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);

		bone3 = new ModelRenderer(this);
		bone3.setRotationPoint(0.0F, -0.5F, -1.1667F);
		bone.addChild(bone3);
		setRotationAngle(bone3, 0.0F, 0.0F, 1.5708F);
		bone3.setTextureOffset(0, 0).addBox(1.0F, -0.5F, -0.8333F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone3.setTextureOffset(0, 2).addBox(-5.0F, -0.5F, -0.8333F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone3.setTextureOffset(0, 4).addBox(-2.0F, -0.5F, 0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);

		bone4 = new ModelRenderer(this);
		bone4.setRotationPoint(0.0F, 0.0F, -3.0F);
		bone.addChild(bone4);
		bone4.setTextureOffset(0, 0).addBox(1.0F, -1.0F, 1.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone4.setTextureOffset(0, 2).addBox(-5.0F, -1.0F, 1.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone4.setTextureOffset(0, 4).addBox(-2.0F, -1.0F, 2.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);

		bone5 = new ModelRenderer(this);
		bone5.setRotationPoint(0.0F, 24.0F, 0.0F);
		setRotationAngle(bone5, 0.0F, -1.5708F, 0.0F);
		bone5.setTextureOffset(0, 0).addBox(1.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone5.setTextureOffset(0, 2).addBox(-5.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone5.setTextureOffset(0, 4).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 1.0F, 0.0F, false);

		bone6 = new ModelRenderer(this);
		bone6.setRotationPoint(0.0F, -0.5F, -0.3333F);
		bone5.addChild(bone6);
		setRotationAngle(bone6, 0.0F, 0.0F, 1.5708F);
		bone6.setTextureOffset(0, 0).addBox(1.0F, -0.5F, -0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone6.setTextureOffset(0, 2).addBox(-5.0F, -0.5F, -0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone6.setTextureOffset(0, 4).addBox(-2.0F, -0.5F, -1.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);

		bone7 = new ModelRenderer(this);
		bone7.setRotationPoint(0.0F, -0.5F, 0.3333F);
		bone5.addChild(bone7);
		setRotationAngle(bone7, 0.0F, 0.0F, 1.5708F);
		bone7.setTextureOffset(0, 0).addBox(1.0F, -0.5F, -0.8333F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone7.setTextureOffset(0, 2).addBox(-5.0F, -0.5F, -0.8333F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone7.setTextureOffset(0, 4).addBox(-2.0F, -0.5F, 0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);

		bone8 = new ModelRenderer(this);
		bone8.setRotationPoint(0.0F, 0.0F, -1.5F);
		bone5.addChild(bone8);
		bone8.setTextureOffset(0, 0).addBox(1.0F, -1.0F, 1.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone8.setTextureOffset(0, 2).addBox(-5.0F, -1.0F, 1.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		bone8.setTextureOffset(0, 4).addBox(-2.0F, -1.0F, 2.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red,
			float green, float blue, float alpha) {
		bone.render(matrixStack, buffer, packedLight, packedOverlay);
		bone5.render(matrixStack, buffer, packedLight, packedOverlay);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, e);
	}
}