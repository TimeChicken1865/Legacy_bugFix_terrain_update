
package net.mcreator.asurvivorslegacy.gui;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import net.minecraft.client.Minecraft;

import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.matrix.MatrixStack;

@OnlyIn(Dist.CLIENT)
public class StoryGuiWindow extends ContainerScreen<StoryGui.GuiContainerMod> {
	private World world;
	private int x, y, z;
	private PlayerEntity entity;
	private final static HashMap guistate = StoryGui.guistate;
	public StoryGuiWindow(StoryGui.GuiContainerMod container, PlayerInventory inventory, ITextComponent text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.xSize = 434;
		this.ySize = 241;
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}
	private static final ResourceLocation texture = new ResourceLocation("a_survivors_legacy:textures/story.png");
	@Override
	public void render(MatrixStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderHoveredTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void drawGuiContainerBackgroundLayer(MatrixStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.color4f(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		Minecraft.getInstance().getTextureManager().bindTexture(texture);
		int k = (this.width - this.xSize) / 2;
		int l = (this.height - this.ySize) / 2;
		this.blit(ms, k, l, 0, 0, this.xSize, this.ySize, this.xSize, this.ySize);
		Minecraft.getInstance().getTextureManager().bindTexture(new ResourceLocation("a_survivors_legacy:textures/backk.png"));
		this.blit(ms, this.guiLeft + -35, this.guiTop + -50, 0, 0, 498, 325, 498, 325);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeScreen();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void tick() {
		super.tick();
	}

	@Override
	protected void drawGuiContainerForegroundLayer(MatrixStack ms, int mouseX, int mouseY) {
		this.font.drawString(ms, "Hello mortal friend... your world has just been hit by something known as magic", 29, 9, -6710887);
		this.font.drawString(ms, "concentrate... It is extremely deadly and you were killed instantly", 15, 27, -6710887);
		this.font.drawString(ms, "but don't worry we have given you a second chance in our world, which is", 15, 42, -6710887);
		this.font.drawString(ms, "on the brink of war with demons and monsters... if you can save this world", 16, 57, -6710887);
		this.font.drawString(ms, "we will rewind time for you and save yours!", 18, 72, -6710887);
		this.font.drawString(ms, "Don't worry we will transport you to a town with a legendary sword, you are to", 37, 90, -6710887);
		this.font.drawString(ms, "pull it out of the stone and you will be granted the power to wield it...", 20, 106, -6710887);
		this.font.drawString(ms, "it comes with the special porperties to unlock your mana within and you can grow ", 20, 121, -6710887);
		this.font.drawString(ms, "stronger with the sword... we wish you the best of luck.", 21, 133, -6710887);
		this.font.drawString(ms, "if you choose to go it will take us a few moments to transport you", 43, 192, -6710887);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardListener.enableRepeatEvents(false);
	}

	@Override
	public void init(Minecraft minecraft, int width, int height) {
		super.init(minecraft, width, height);
		minecraft.keyboardListener.enableRepeatEvents(true);
		this.addButton(new Button(this.guiLeft + 186, this.guiTop + 165, 50, 20, new StringTextComponent("Begin"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new StoryGui.ButtonPressedMessage(0, x, y, z));
				StoryGui.handleButtonAction(entity, 0, x, y, z);
			}
		}));
	}
}
