
package net.mcreator.asurvivorslegacy.gui;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import net.minecraft.client.Minecraft;

import net.mcreator.asurvivorslegacy.procedures.Equipp3Procedure;
import net.mcreator.asurvivorslegacy.procedures.Equipp2Procedure;
import net.mcreator.asurvivorslegacy.procedures.Equip1Procedure;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.matrix.MatrixStack;

import com.google.common.collect.ImmutableMap;

@OnlyIn(Dist.CLIENT)
public class ManaGUIGuiWindow extends ContainerScreen<ManaGUIGui.GuiContainerMod> {
	private World world;
	private int x, y, z;
	private PlayerEntity entity;
	private final static HashMap guistate = ManaGUIGui.guistate;
	public ManaGUIGuiWindow(ManaGUIGui.GuiContainerMod container, PlayerInventory inventory, ITextComponent text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.xSize = 176;
		this.ySize = 166;
	}
	private static final ResourceLocation texture = new ResourceLocation("a_survivors_legacy:textures/mana_gui.png");
	@Override
	public void render(MatrixStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderHoveredTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void drawGuiContainerBackgroundLayer(MatrixStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.color4f(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		Minecraft.getInstance().getTextureManager().bindTexture(texture);
		int k = (this.width - this.xSize) / 2;
		int l = (this.height - this.ySize) / 2;
		this.blit(ms, k, l, 0, 0, this.xSize, this.ySize, this.xSize, this.ySize);
		Minecraft.getInstance().getTextureManager().bindTexture(new ResourceLocation("a_survivors_legacy:textures/backk.png"));
		this.blit(ms, this.guiLeft + -164, this.guiTop + -65, 0, 0, 498, 325, 498, 325);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeScreen();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void tick() {
		super.tick();
	}

	@Override
	protected void drawGuiContainerForegroundLayer(MatrixStack ms, int mouseX, int mouseY) {
		this.font.drawString(ms, "Xp cost:5", 145, -12, -13369600);
		this.font.drawString(ms, "Xp cost:6", -6, 67, -16711936);
		this.font.drawString(ms, "Xp cost:6", 133, 67, -16711936);
		this.font.drawString(ms, "Xp cost:6", 254, 64, -16711936);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardListener.enableRepeatEvents(false);
	}

	@Override
	public void init(Minecraft minecraft, int width, int height) {
		super.init(minecraft, width, height);
		minecraft.keyboardListener.enableRepeatEvents(true);
		this.addButton(new Button(this.guiLeft + 42, this.guiTop + -17, 100, 20, new StringTextComponent("mana multiplier"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(0, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 0, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + -74, this.guiTop + 61, 65, 20, new StringTextComponent("Fireball"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(1, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 1, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + -67, this.guiTop + 82, 50, 20, new StringTextComponent("equip"), e -> {
			if (Equip1Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(2, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 2, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (Equip1Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 59, this.guiTop + 62, 70, 20, new StringTextComponent("Waterball"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(3, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 3, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 68, this.guiTop + 83, 50, 20, new StringTextComponent("equip"), e -> {
			if (Equipp2Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(4, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 4, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (Equipp2Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 194, this.guiTop + 61, 60, 20, new StringTextComponent("Mudball"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(5, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 5, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 199, this.guiTop + 82, 50, 20, new StringTextComponent("equip"), e -> {
			if (Equipp3Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(6, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 6, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (Equipp3Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + -101, this.guiTop + 34, 130, 20, new StringTextComponent("Magic Attack 1 Editor"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(7, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 7, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 33, this.guiTop + 34, 130, 20, new StringTextComponent("Magic Attack 2 Editor"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(8, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 8, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 168, this.guiTop + 34, 130, 20, new StringTextComponent("Magic Attack 3 Editor"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ManaGUIGui.ButtonPressedMessage(9, x, y, z));
				ManaGUIGui.handleButtonAction(entity, 9, x, y, z);
			}
		}));
	}
}
