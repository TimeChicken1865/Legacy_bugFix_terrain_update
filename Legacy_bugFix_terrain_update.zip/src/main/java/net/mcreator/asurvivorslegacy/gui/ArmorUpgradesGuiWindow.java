
package net.mcreator.asurvivorslegacy.gui;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import net.minecraft.client.Minecraft;

import net.mcreator.asurvivorslegacy.procedures.EquipDef3Procedure;
import net.mcreator.asurvivorslegacy.procedures.EquipDef2Procedure;
import net.mcreator.asurvivorslegacy.procedures.EquipDef1Procedure;
import net.mcreator.asurvivorslegacy.procedures.Defensemultiplierability3Procedure;
import net.mcreator.asurvivorslegacy.procedures.Defensemultiplierability2Procedure;
import net.mcreator.asurvivorslegacy.procedures.Defensemultiplier1showabilityProcedure;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.matrix.MatrixStack;

import com.google.common.collect.ImmutableMap;

@OnlyIn(Dist.CLIENT)
public class ArmorUpgradesGuiWindow extends ContainerScreen<ArmorUpgradesGui.GuiContainerMod> {
	private World world;
	private int x, y, z;
	private PlayerEntity entity;
	private final static HashMap guistate = ArmorUpgradesGui.guistate;
	public ArmorUpgradesGuiWindow(ArmorUpgradesGui.GuiContainerMod container, PlayerInventory inventory, ITextComponent text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.xSize = 176;
		this.ySize = 166;
	}
	private static final ResourceLocation texture = new ResourceLocation("a_survivors_legacy:textures/armor_upgrades.png");
	@Override
	public void render(MatrixStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderHoveredTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void drawGuiContainerBackgroundLayer(MatrixStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.color4f(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		Minecraft.getInstance().getTextureManager().bindTexture(texture);
		int k = (this.width - this.xSize) / 2;
		int l = (this.height - this.ySize) / 2;
		this.blit(ms, k, l, 0, 0, this.xSize, this.ySize, this.xSize, this.ySize);
		Minecraft.getInstance().getTextureManager().bindTexture(new ResourceLocation("a_survivors_legacy:textures/backk.png"));
		this.blit(ms, this.guiLeft + -158, this.guiTop + -66, 0, 0, 498, 325, 498, 325);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeScreen();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void tick() {
		super.tick();
	}

	@Override
	protected void drawGuiContainerForegroundLayer(MatrixStack ms, int mouseX, int mouseY) {
		this.font.drawString(ms, "Xp cost:5", 152, -23, -16711936);
		this.font.drawString(ms, "Xp cost:7", -76, 13, -16711936);
		this.font.drawString(ms, "Xp cost:10", 63, 16, -16711936);
		this.font.drawString(ms, "Xp cost:8", 204, 13, -16711885);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardListener.enableRepeatEvents(false);
	}

	@Override
	public void init(Minecraft minecraft, int width, int height) {
		super.init(minecraft, width, height);
		minecraft.keyboardListener.enableRepeatEvents(true);
		this.addButton(new Button(this.guiLeft + 34, this.guiTop + -27, 115, 20, new StringTextComponent("Defense Multiplier"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ArmorUpgradesGui.ButtonPressedMessage(0, x, y, z));
				ArmorUpgradesGui.handleButtonAction(entity, 0, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 31, this.guiTop + 32, 115, 20, new StringTextComponent("blessing o' health"), e -> {
			if (Defensemultiplierability3Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ArmorUpgradesGui.ButtonPressedMessage(1, x, y, z));
				ArmorUpgradesGui.handleButtonAction(entity, 1, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (Defensemultiplierability3Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 188, this.guiTop + 32, 75, 20, new StringTextComponent("flash step"), e -> {
			if (Defensemultiplierability2Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ArmorUpgradesGui.ButtonPressedMessage(2, x, y, z));
				ArmorUpgradesGui.handleButtonAction(entity, 2, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (Defensemultiplierability2Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + -106, this.guiTop + 32, 105, 20, new StringTextComponent("Limit break leap1"), e -> {
			if (Defensemultiplier1showabilityProcedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ArmorUpgradesGui.ButtonPressedMessage(3, x, y, z));
				ArmorUpgradesGui.handleButtonAction(entity, 3, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (Defensemultiplier1showabilityProcedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + -81, this.guiTop + 55, 50, 20, new StringTextComponent("equip"), e -> {
			if (EquipDef1Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ArmorUpgradesGui.ButtonPressedMessage(4, x, y, z));
				ArmorUpgradesGui.handleButtonAction(entity, 4, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (EquipDef1Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 62, this.guiTop + 56, 50, 20, new StringTextComponent("equip"), e -> {
			if (EquipDef3Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ArmorUpgradesGui.ButtonPressedMessage(5, x, y, z));
				ArmorUpgradesGui.handleButtonAction(entity, 5, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (EquipDef3Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 201, this.guiTop + 57, 50, 20, new StringTextComponent("equip"), e -> {
			if (EquipDef2Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new ArmorUpgradesGui.ButtonPressedMessage(6, x, y, z));
				ArmorUpgradesGui.handleButtonAction(entity, 6, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (EquipDef2Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
	}
}
