
package net.mcreator.asurvivorslegacy.item;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.World;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.ArmorItem;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.entity.model.BipedModel;

import net.mcreator.asurvivorslegacy.procedures.ArcmoschestplateinuseBodyTickEventProcedure;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModElements;

import java.util.Map;
import java.util.HashMap;

import com.mojang.blaze3d.vertex.IVertexBuilder;
import com.mojang.blaze3d.matrix.MatrixStack;

@ASurvivorsLegacyModElements.ModElement.Tag
public class ArcmoschestplateinuseItem extends ASurvivorsLegacyModElements.ModElement {
	@ObjectHolder("a_survivors_legacy:arcmoschestplateinuse_helmet")
	public static final Item helmet = null;
	@ObjectHolder("a_survivors_legacy:arcmoschestplateinuse_chestplate")
	public static final Item body = null;
	@ObjectHolder("a_survivors_legacy:arcmoschestplateinuse_leggings")
	public static final Item legs = null;
	@ObjectHolder("a_survivors_legacy:arcmoschestplateinuse_boots")
	public static final Item boots = null;
	public ArcmoschestplateinuseItem(ASurvivorsLegacyModElements instance) {
		super(instance, 131);
	}

	@Override
	public void initElements() {
		IArmorMaterial armormaterial = new IArmorMaterial() {
			@Override
			public int getDurability(EquipmentSlotType slot) {
				return new int[]{13, 15, 16, 11}[slot.getIndex()] * 25;
			}

			@Override
			public int getDamageReductionAmount(EquipmentSlotType slot) {
				return new int[]{2, 5, 6, 2}[slot.getIndex()];
			}

			@Override
			public int getEnchantability() {
				return 9;
			}

			@Override
			public net.minecraft.util.SoundEvent getSoundEvent() {
				return (net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(""));
			}

			@Override
			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}

			@OnlyIn(Dist.CLIENT)
			@Override
			public String getName() {
				return "arcmoschestplateinuse";
			}

			@Override
			public float getToughness() {
				return 0f;
			}

			@Override
			public float getKnockbackResistance() {
				return 0f;
			}
		};
		elements.items.add(() -> new ArmorItem(armormaterial, EquipmentSlotType.HEAD, new Item.Properties().group(ItemGroup.COMBAT)) {
			@Override
			public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlotType slot, String type) {
				return "a_survivors_legacy:textures/models/armor/succ_layer_" + (slot == EquipmentSlotType.LEGS ? "2" : "1") + ".png";
			}
		}.setRegistryName("arcmoschestplateinuse_helmet"));
		elements.items.add(() -> new ArmorItem(armormaterial, EquipmentSlotType.CHEST, new Item.Properties().group(ItemGroup.COMBAT)) {
			@Override
			@OnlyIn(Dist.CLIENT)
			public BipedModel getArmorModel(LivingEntity living, ItemStack stack, EquipmentSlotType slot, BipedModel defaultModel) {
				BipedModel armorModel = new BipedModel(1);
				armorModel.bipedBody = new Modelarcchestnosw().Body;
				armorModel.bipedLeftArm = new Modelarcchestnosw().LeftArm;
				armorModel.bipedRightArm = new Modelarcchestnosw().RightArm;
				armorModel.isSneak = living.isSneaking();
				armorModel.isSitting = defaultModel.isSitting;
				armorModel.isChild = living.isChild();
				return armorModel;
			}

			@Override
			public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlotType slot, String type) {
				return "a_survivors_legacy:textures/arcchestnosw.png";
			}

			@Override
			public void onArmorTick(ItemStack itemstack, World world, PlayerEntity entity) {
				double x = entity.getPosX();
				double y = entity.getPosY();
				double z = entity.getPosZ();
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					$_dependencies.put("itemstack", itemstack);
					ArcmoschestplateinuseBodyTickEventProcedure.executeProcedure($_dependencies);
				}
			}
		}.setRegistryName("arcmoschestplateinuse_chestplate"));
		elements.items.add(() -> new ArmorItem(armormaterial, EquipmentSlotType.LEGS, new Item.Properties().group(ItemGroup.COMBAT)) {
			@Override
			public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlotType slot, String type) {
				return "a_survivors_legacy:textures/models/armor/succ_layer_" + (slot == EquipmentSlotType.LEGS ? "2" : "1") + ".png";
			}
		}.setRegistryName("arcmoschestplateinuse_leggings"));
		elements.items.add(() -> new ArmorItem(armormaterial, EquipmentSlotType.FEET, new Item.Properties().group(ItemGroup.COMBAT)) {
			@Override
			public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlotType slot, String type) {
				return "a_survivors_legacy:textures/models/armor/succ_layer_" + (slot == EquipmentSlotType.LEGS ? "2" : "1") + ".png";
			}
		}.setRegistryName("arcmoschestplateinuse_boots"));
	}
	// Made with Blockbench 3.9.2
	// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
	// Paste this class into your mod and generate all required imports
	public static class Modelarcchestnosw extends EntityModel<Entity> {
		private final ModelRenderer Head;
		private final ModelRenderer Body;
		private final ModelRenderer Body_r1;
		private final ModelRenderer Body_r2;
		private final ModelRenderer Body_r3;
		private final ModelRenderer RightArm;
		private final ModelRenderer LeftArm;
		private final ModelRenderer RightLeg;
		private final ModelRenderer LeftLeg;
		public Modelarcchestnosw() {
			textureWidth = 64;
			textureHeight = 64;
			Head = new ModelRenderer(this);
			Head.setRotationPoint(0.0F, 0.0F, 0.0F);
			Body = new ModelRenderer(this);
			Body.setRotationPoint(0.0F, 0.0F, 0.0F);
			Body.setTextureOffset(0, 0).addBox(-4.0F, 0.0F, -3.0F, 8.0F, 8.0F, 6.0F, 0.0F, false);
			Body.setTextureOffset(0, 7).addBox(-4.0F, 8.0F, -3.0F, 8.0F, 6.0F, 6.0F, 0.0F, false);
			Body.setTextureOffset(24, 25).addBox(-4.0F, -0.5F, -3.75F, 1.0F, 1.0F, 7.0F, 0.0F, false);
			Body.setTextureOffset(15, 24).addBox(3.25F, 7.25F, -3.75F, 1.0F, 1.0F, 7.0F, 0.0F, false);
			Body.setTextureOffset(16, 32).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, 0.25F, false);
			Body_r1 = new ModelRenderer(this);
			Body_r1.setRotationPoint(-3.0F, 1.0F, 3.0F);
			Body.addChild(Body_r1);
			setRotationAngle(Body_r1, 0.5236F, -0.5236F, 0.0F);
			Body_r1.setTextureOffset(16, 32).addBox(-0.5F, -0.5F, 4.0F, 1.0F, 1.0F, 3.0F, 0.0F, false);
			Body_r1.setTextureOffset(28, 4).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F, 0.0F, false);
			Body_r2 = new ModelRenderer(this);
			Body_r2.setRotationPoint(3.0F, 1.0F, 3.0F);
			Body.addChild(Body_r2);
			setRotationAngle(Body_r2, 0.5236F, 0.5236F, 0.0F);
			Body_r2.setTextureOffset(21, 33).addBox(-0.5F, -0.5F, 4.0F, 1.0F, 1.0F, 3.0F, 0.0F, false);
			Body_r2.setTextureOffset(4, 30).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F, 0.0F, false);
			Body_r3 = new ModelRenderer(this);
			Body_r3.setRotationPoint(0.0F, 0.5F, 3.5F);
			Body.addChild(Body_r3);
			setRotationAngle(Body_r3, 0.0F, 0.0F, 0.7854F);
			Body_r3.setTextureOffset(22, 0).addBox(-3.0F, 1.75F, -1.0F, 11.0F, 1.0F, 1.0F, 0.0F, false);
			Body_r3.setTextureOffset(22, 2).addBox(-3.0F, 1.75F, -7.25F, 11.0F, 1.0F, 1.0F, 0.0F, false);
			RightArm = new ModelRenderer(this);
			RightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
			RightArm.setTextureOffset(22, 12).addBox(-4.0F, -2.0F, -3.0F, 5.0F, 6.0F, 6.0F, 0.0F, false);
			RightArm.setTextureOffset(40, 32).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, 0.25F, false);
			LeftArm = new ModelRenderer(this);
			LeftArm.setRotationPoint(6.0F, 2.0F, 0.0F);
			LeftArm.setTextureOffset(0, 18).addBox(-2.0F, -2.0F, -3.0F, 6.0F, 6.0F, 6.0F, 0.0F, false);
			LeftArm.setTextureOffset(48, 48).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 6.0F, 4.0F, 0.25F, false);
			RightLeg = new ModelRenderer(this);
			RightLeg.setRotationPoint(-1.9F, 12.0F, 0.0F);
			LeftLeg = new ModelRenderer(this);
			LeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);
		}

		@Override
		public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue,
				float alpha) {
			Head.render(matrixStack, buffer, packedLight, packedOverlay);
			Body.render(matrixStack, buffer, packedLight, packedOverlay);
			RightArm.render(matrixStack, buffer, packedLight, packedOverlay);
			LeftArm.render(matrixStack, buffer, packedLight, packedOverlay);
			RightLeg.render(matrixStack, buffer, packedLight, packedOverlay);
			LeftLeg.render(matrixStack, buffer, packedLight, packedOverlay);
		}

		public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
			modelRenderer.rotateAngleX = x;
			modelRenderer.rotateAngleY = y;
			modelRenderer.rotateAngleZ = z;
		}

		public void setRotationAngles(Entity e, float f, float f1, float f2, float f3, float f4) {
			this.RightArm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float) Math.PI) * f1;
			this.LeftArm.rotateAngleX = MathHelper.cos(f * 0.6662F) * f1;
		}
	}
}
