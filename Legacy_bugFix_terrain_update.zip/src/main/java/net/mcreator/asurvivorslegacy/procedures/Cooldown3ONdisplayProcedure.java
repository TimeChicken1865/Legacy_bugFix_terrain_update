package net.mcreator.asurvivorslegacy.procedures;

import net.minecraft.entity.Entity;

import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModVariables;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.Map;

public class Cooldown3ONdisplayProcedure {
	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency entity for procedure Cooldown3ONdisplay!");
			return false;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).cooldown1) == (true))) {
			return (true);
		}
		return (false);
	}
}
