package net.mcreator.asurvivorslegacy.procedures;

import net.minecraft.world.IWorld;

import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModVariables;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.Map;

public class DarkelfNaturalEntitySpawningConditionProcedure {
	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency world for procedure DarkelfNaturalEntitySpawningCondition!");
			return false;
		}
		IWorld world = (IWorld) dependencies.get("world");
		if ((ASurvivorsLegacyModVariables.WorldVariables.get(world).MobSpawnDifficulty > 3)) {
			return (true);
		}
		return (false);
	}
}
