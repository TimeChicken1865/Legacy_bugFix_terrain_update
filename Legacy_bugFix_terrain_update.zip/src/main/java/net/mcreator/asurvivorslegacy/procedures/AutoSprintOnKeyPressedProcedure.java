package net.mcreator.asurvivorslegacy.procedures;

import net.minecraft.entity.Entity;

import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModVariables;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.Map;

public class AutoSprintOnKeyPressedProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency entity for procedure AutoSprintOnKeyPressed!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).autosprint) == (true))) {
			{
				boolean _setval = (boolean) (false);
				entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.autosprint = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if (((entity.getPersistentData().getBoolean("tag")) == (false))) {
			if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).autosprint) == (false))) {
				{
					boolean _setval = (boolean) (true);
					entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.autosprint = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				entity.getPersistentData().putBoolean("tag", (true));
			}
		}
		if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).autosprint) == (false))) {
			entity.getPersistentData().putBoolean("tag", (false));
		}
	}
}
