package net.mcreator.asurvivorslegacy.procedures;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;

import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModVariables;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.Map;

public class DashatkProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency entity for procedure Dashatk!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).dashatk) == (false))) {
			if (entity instanceof PlayerEntity)
				((PlayerEntity) entity).addExperienceLevel(-((int) 15));
			{
				boolean _setval = (boolean) (true);
				entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.dashatk = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
